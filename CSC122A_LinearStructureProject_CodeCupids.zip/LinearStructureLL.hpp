/******************************************************
 * CSC 122
 * Linear Structures
 * LinearStructureLL.hpp
 * 
 * Team Name:CodeCupids
 * Team Members:Alice, Vinh, Pony
 * ****************************************************
*/
#ifndef LINEAR_STRUCTURE_LL_HPP
#define LINEAR_STRUCTURE_LL_HPP

// Your class definition and other includes go here
#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* prev;
    Node* next;

    Node(int value) {
       data = value;
       prev = nullptr;
       next = nullptr; 
    }
};

class LinearStructureLL {
private:
    Node* head;
    Node* tail;
    int size;

public:
    // Constructor
    LinearStructureLL() 
    {
        head = nullptr;
        tail = nullptr;
        size = 0;
    }

    /**
     * worst-case time complexity: O(n)
     */
    ~LinearStructureLL() 
    {
      if(head != nullptr)
      {
        Node* current = head;
        Node* next = current;
        while(current != nullptr)
        {
          next = current->next;
          delete current; 
          current = next;
        }
      }
    }

    /**
     * worst-case time complexity: O(1)
     */
    void addToStart(int value) 
    {
        Node* newNode = new Node(value);
        newNode->next = head;
        head = newNode;
        size++;
    }

    /**
     * worst-case time complexity:O(n) if use tail: O(1).
     */
    void addToIndex(int value, int index) 
    {
        Node* current = head;
        Node* newNode = new Node(value);
        if(index == 0) // if want to add to the start
        {
          newNode->next = head;
          head = newNode;
          size++;
          if(size == 1) //update tail if adding to an empty list
          {
            tail = newNode;
          }
        }
        else  // if want to add to the middle or end
        {
          int count = 1;
          while(current->next != nullptr && count < index)
          {
            current = current->next;
            count++;
          }
          if(count == index)
          {
            newNode->next = current->next;
            current->next = newNode;
            size++;
          }
          if(index == size-1) // if add to the end of the list -> time complexity if use tail: O(1).
          {
            tail = newNode;
          }
        }
    }

    /**
     * worst-case time complexity:O(1)
     */
    int removeFromStart() 
    {
      Node* current = head;
      if (head == nullptr) 
      {
          tail = nullptr;
          cout << "List is empty." << endl;
          return -1;
      }
      head = current->next;
      int data = current->data;
      delete current;
      size--;
      return data;
    }

    /**
     * worst-case time complexity:O(n)
     */
    int removeFromIndex(int index) 
    {
      if (size == 0 || index < 0 || index >= size)
      {
          cout << "Invalid index" << endl;
          return -1;
      }
      else if (index == 0)
      {
          Node* current = head;
          head = current->next;
          int data = current->data;
          delete current;
          size--;
          if (head == nullptr)
          {
              tail = nullptr;
          }
          return data;
      }
      else
      {
          Node* current = head;
          int count = 1;
          while (count < index)
          {
              current = current->next;
              count++;
          }
          Node* nodeToRemove = current->next;
          current->next = current->next->next;
          int data = nodeToRemove->data;
          delete nodeToRemove;
          size--;
          if (index == size-1)
          {
              tail = current;
          }
          return data;
      }
    }

    //wrapper
    void printAll()
    {
        if(head != nullptr)
        {
          printAllRec(head);
          cout<<endl;
        }
        else
        {
          cout<<"Cannot print null"<< endl;
        }
    }

    /**
     * worst-case time complexity: O(n) , recursive O(n)
     */
    void printAllRec(Node* current) 
    {
        if(current != nullptr)
        {
            cout << current->data << " ";
            printAllRec(current->next);
        }
    }

    /**
     * worst-case time complexity:O(n)
     */
    int get(int index) 
    {
        Node* current = head;
        int count = 0;
        if(index < 0)
        {
            cout << "Invalid index." << endl;
            return -1;
        }
        else
        {
            while(current->next != nullptr && count < index)
            {
                if(count == index)
                {
                    return current->data;
                }
                count++;
                current = current->next;
            }
            return -1;
        }
    }

    /**
     * worst-case time complexity:O(1)
     */
    int getSize()
    {
      // since the adding and removing functions update the size every time it is called, 
      // the size variable will be updated constantly -> we can just return size without 
      // having to traverse through the entire linked list.
        return size; 
    }
};

#endif // LINEAR_STRUCTURE_LL_HPP