/******************************************************
 * CSC 122
 * Linear Structures
 * LinearStructureArray.hpp
 * 
 * Team Name: CodeCupids
 * Team Members: Alice, Vinh, Pony
 * ****************************************************
*/
#ifndef LINEAR_STRUCTURE_ARRAY_HPP
#define LINEAR_STRUCTURE_ARRAY_HPP

// Your class definition and other includes go here
#include <iostream>
using namespace std;

class LinearStructureArray {
private:
    int* elements; // Array to store elements
    int capacity;
    int size;      // Current size of the array

public:
    LinearStructureArray(int initialSize) 
    {
        capacity = initialSize;
        elements = new int[capacity];
        size = 0;
    }

    /**
     * worst-case time complexity: O(1)
     */
    ~LinearStructureArray() {
    delete[] elements; // Deleting the array
}

    /**
     * worst-case time complexity:O(n)
     */
    void resize() 
    {
      int newCapacity = capacity * 2;
      int* newArray = new int[newCapacity];
      for(int i =0; i<size; i++)
      {
        newArray[i] = elements[i];
      }
     delete[] elements; // Deleting the old array
     elements = newArray; // Pointing elements to the new array
     capacity = newCapacity;
    }

    
    /**
     * worst-case time complexity:O(n)
     */
    void addToStart(int value) 
  {
        if (size == capacity) {
            resize();
        }

        if (size < capacity) {
            for (int i = size; i > 0; --i) {
                elements[i] = elements[i - 1];// Shift elements to the right
            }
            elements[0] = value; // Insert the new element at the beginning
            size += 1;
        }
    }

    /**
     * worst-case time complexity:O(n)
     */
void addToIndex(int value, int index)
{
     if (index < 0 || index > size) 
     {
        cout << "Invalid Index" << endl;
        return;
        // Print an error message for an invalid index
     }
     if(size < capacity)
     {
        for(int i = size - 1; i >= index; i--){
            elements[i + 1] = elements[i]; // Shift elements to the right
        }
        elements[index] = value; // Insert the new element at the specified index
        size += 1;
    }

 }

    /**
     * worst-case time complexity: O(n)
     */
int removeFromStart() {
    if (size > 0) {
        int value = elements[0]; // Retrieve the value of the removed element
        for (int i = 0; i < size - 1; ++i) {
            elements[i] = elements[i + 1]; // Shift elements to the left
        }
        size -= 1;
        return value;
    }
    return -1;
}

    /**
     * worst-case time complexity: O(n)
     */
    int removeFromIndex(int index) 
    {
        if (index < 0 || index >= size) 
        {
            return -1;
        }

        int removedElement = elements[index];
        for (int i = index; i < size - 1; ++i) 
        {
            elements[i] = elements[i + 1];
        }
        --size;
        return removedElement;
    }

    /**
     * worst-case time complexity: O(1)
     */
    int getSize() 
    {
        return size;
    }

    /**
     * worst-case time complexity: O(1)
     */
    int get(int index) 
    {
        if (index < 0 || index >= size) 
        {
            return -1;
        }

        return elements[index];
    }

    

    /**
     * worst-case time complexity: O(n) , recursive O(n)
     */
    void printAllRecursive(int arr[], int size, int index) 
    {
        if (index == size) 
        {
            std::cout << std::endl;
            return;
        }
        std::cout << elements[index] << " ";
        printAllRecursive(elements, size, index + 1);
    }

    void printAll() 
    {
        printAllRecursive(elements, size, 0);
    }

};
#endif // LINEAR_STRUCTURE_ARRAY_HPP